import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { catchError } from 'rxjs/internal/operators/catchError';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private totalItems: BehaviorSubject<number> = new BehaviorSubject<number>(0);

  getCartItems() {
    return this.totalItems.asObservable();
}

updateCartItems(items: number) {
    this.totalItems.next(items);
}

  constructor(private http: HttpClient) { }

  getList():Observable<any>{
    return this.http.get(environment.listURL)
    .pipe(
      map(result => result)
    )
  }


}
