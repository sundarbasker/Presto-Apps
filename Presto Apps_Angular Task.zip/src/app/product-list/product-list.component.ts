import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  products: any;
  total;
  cartTotal;
  tax;
  shippingCharges;
  constructor(private data: DataService) { }

  increase(i) {
    this.data.updateCartItems(this.total + 1);
    console.log(this.total);
    this.products.data[i]['quantatity'] = Number(this.products.data[i]['quantatity']) + 1
    this.getTotal(this.products.data);

  }
  selectedItem = 0;
  getTotal(data) {
    console.log(data);

    let total = 0;
    let productList = 0;
    data.map(item => {
      if (item.quantatity > 0) {
        total = total + (item.quantatity * Number(item.rate));
        productList = productList + 1;
      }
    })


    this.cartTotal = total;
    this.selectedItem = productList;
    this.tax = (total * 18) / 100;
    this.shippingCharges = (total * 2) / 100;
  }
  decrease(i) {
    this.data.updateCartItems(this.total - 1);
    this.products.data[i]['quantatity'] = Number(this.products.data[i]['quantatity']) - 1
    this.getTotal(this.products.data);
    if (this.products.data[i]['quantatity'] < 1) {
      this.products.data[i]['quantatity'] = 0;
    }

  }

  ngOnInit(): void {
    this.data.getList().subscribe(data => {

      this.products = data;
      console.log(this.products);

    }),

      this.data.getCartItems()
        .subscribe(value => {
          this.total = value;
        })

  }

}
